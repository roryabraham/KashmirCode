$(function(){
    $("#experienceSection").accordion({
        collapsible: true,
        heightStyle: "content"
    });
});